import pandas as pd
from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import requests.exceptions
import sys
from ericuis.main import UserInputService
from .config import bot_payload
import xlrd
import openpyxl
import json
import os

#INPATH='C:\\Users\\enanama\\OneDrive - Ericsson\\Amar Doc\\Ericsson\\Python\\BOT\BOT\\DPcancellation\\INPATH\\'
#OUTPATH=INPATH

def doProcess(INPATH='.', OUTPATH='.', wo_details='.'):
    try:
        #UIS
        bot_obj = UserInputService(bot_payload, wo_details)
        bot_data = bot_obj.get_values()    
        userid = bot_data["UserID"]
        password = bot_data["Password"]
         #Open DP lists
        df = pd.read_excel(INPATH+'DP_TXW.xlsx')
        try:
            # Load the webdriver.Chrome
            chrome_options = webdriver.ChromeOptions()
            chrome_options.add_argument("webdriver.chrome.driver=INPATH")
            browser = webdriver.Chrome(options=chrome_options)
                        
            browser.get("https://sitehandler-emea4.ericsson.net/")
            time.sleep(2)
            #open details sheet
            df1 = pd.read_excel(INPATH+'Details.xlsx')

            #username & Password
            browser.maximize_window()
            user=browser.find_element(By.NAME,"j_username")
            #user.send_keys((df1['SHUserid']))
            user.send_keys(userid)
            user=browser.find_element(By.NAME,"j_password")
            #user.send_keys((df1['SHPassword']))
            user.send_keys(password)
            time.sleep(2)
            # Go to Single Client Page
            browser.find_element(By.XPATH,"//*[@id='b_submit']").click()
            time.sleep(5)
            browser.find_element(By.XPATH,"//*[@id='continue']").click()
            #open VICC left panel
            time.sleep(2)
            browser.find_element(By.XPATH,"//*[@id='17004']/div[1]/a/span").click()
            time.sleep(2)
            browser.find_element(By.XPATH,"//*[@id='9465']/a").click()
            time.sleep(5)
            #switch to TxW frame
            time.sleep(4)
            browser.find_element(By.XPATH,"//*[@id='12730']/a").click()
            time.sleep(4)
            browser.find_element(By.XPATH,"//*[@id='12730']/a").click()
            time.sleep(4)
            #switch to TXW frame
            browser.switch_to.frame("iframe")
            for r in range (len(df)):
                    time.sleep(2)                    
                    browser.find_element(By.NAME,'pattern').clear()
                    browser.find_element(By.NAME,'pattern').send_keys(int(df['TX Work'][r]))
                    browser.find_element(By.NAME,'pattern').send_keys(Keys.RETURN)
                    time.sleep(2)
                    element=browser.find_element(By.XPATH,"//*[@id='objects']")
                    drop=Select(element)
                    drop.select_by_visible_text(str(df['TX Work'][r]))
                    if (str(df["DP_ID_B"][r]))!= 'nan':
                        time.sleep(2)               
                        browser.find_element(By.XPATH,"//input[contains(@id,'_181949')]").send_keys(int(df['DP_ID_B'][r]))
                        time.sleep(5)
                        browser.find_element(By.XPATH,"//div[contains(@id,'_181949')]").click()
                        time.sleep(5)
                        browser.find_element(By.XPATH,"//div[contains(@id,'_181949')]").click()
                        time.sleep(5)
                        txw1=browser.find_element(By.XPATH,"//select[contains(@id,'_182329')]")
                        drop1=Select(txw1)
                        drop1.select_by_index(5)
                        
                    if (str(df["DP_ID_A"][r]))!= 'nan':
                        time.sleep(2)
                        browser.find_element(By.XPATH,"//input[contains(@id,'_181950')]").send_keys(int(df['DP_ID_A'][r]))
                        time.sleep(5)
                        browser.find_element(By.XPATH,"//div[contains(@id,'_181950')]").click()
                        time.sleep(5)
                        browser.find_element(By.XPATH,"//div[contains(@id,'_181950')]").click()
                        time.sleep(5)
                        txw2=browser.find_element(By.XPATH,"//select[contains(@id,'_182328')]")
                        drop2=Select(txw2)
                        drop2.select_by_index(5)

                       
                    time.sleep(3)    
                    browser.find_element(By.XPATH,"//*[@id='buttonRow']/td/input[1]").click()
                    df['TXW_Status'][r] = "DP Updated"
                    time.sleep(2)

            #Logout
            browser.switch_to.default_content()
            browser.find_element(By.XPATH,"//*[@id='logout']").click()  
            browser.close()
            browser.quit()

        except Exception as except1 :
            print(except1)
            print(type(except1))        
            pass
        df.to_excel(INPATH+'DP_TXW_Update.xlsx',index = False)
    except Exception as e :
        raise e
#doProcess(INPATH, OUTPATH)
