bot_payload={
    "fields":[{
            "fieldName":"UserID",
            "fieldType":"TextBox",
            "fieldValueType":"Text",
            "encryptionReq":"No",
            "maskingReq":"No"
       },
       { 
            "fieldName":"Password",
            "fieldType":"TextBox",
            "fieldValueType":"TextNumeric",
            "encryptionReq":"yes",
            "maskingReq":"yes"
       }
    ]
}

        
